import {Component} from "@angular/core" // all building blocks
// in angular after creation we need registration
// all propeties are available to only their html

var name = "Ashu Lekhi"  // \variable

@Component({
    selector:'app-navbar',
    templateUrl:'./navbar.component.html'
})
export class NavbarComponent {
projectname = "My Shopping Kart"  // property 
}

