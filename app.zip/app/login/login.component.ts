import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login(){
    console.log("login started with", this.user)
  }

  user ={
    email:'',
    password:''
  }
  constructor(private http : HttpClient) { 
    var url = "https://apibyashu.herokuapp.com/api/login"
    this.http.post(url,this.user).subscribe((response)=>{
      console.log("response from login api", response)
    },(error)=>{
      console.log("error from login api", error)
    })
  }

  ngOnInit(): void {
  }

}
