import { Injectable } from '@angular/core';

@Injectable()
export class CommonService{
   somecommondeata = null

   somecommonmethod(){
       
   }
}