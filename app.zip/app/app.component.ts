import { Component , Output} from '@angular/core';
import data from './products'
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(){
    console.log("construction of app component begins")
  }

  ngOnInit(){
    console.log("Component is successfuly created")
  }

  demo(){
    alert("I am in Parent")
  }
  title = 'angularmayvirtual';
  products = data
 


}
