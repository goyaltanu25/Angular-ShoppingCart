import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes, Router} from "@angular/router"
import { AdminComponent } from './admin.component';

var adminroutes : Routes = [
  {path:'',component:AdminComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(adminroutes)
  ],
  exports:[RouterModule]
})
export class AdminModule { }
