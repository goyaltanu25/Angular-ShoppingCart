import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms"
import {HttpClientModule} from "@angular/common/http"

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {NavbarComponent} from "./navbar/navbar.component";
import { CarouselComponent } from './carousel/carousel.component';
import { ProductComponent } from './product/product.component';
import { SignupComponent } from './signup/signup.component'
import { CommonService } from './common.service';
import { LoginComponent } from './login/login.component';
import { NewComponent } from './new/new.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { ForgotComponent } from './forgot/forgot.component';
import { CartComponent } from './cart/cart.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { ShowproductComponent } from './showproduct/showproduct.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { HighlightDirective } from './highlight.directive';
import { DiscountPipe } from './discount.pipe';

@NgModule({
  declarations: [
    AppComponent,NavbarComponent, DiscountPipe,ShowproductComponent ,CarouselComponent, ProductComponent, SignupComponent, LoginComponent, NewComponent, ProductlistComponent, ForgotComponent, CartComponent, NotfoundComponent, CheckoutComponent, HighlightDirective  // Directives, components ,pipes
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    BrowserModule,   // modules
    AppRoutingModule
  ],
  providers: [CommonService],  // Injectables
  bootstrap: [NewComponent]// root component // array is for confusion it will contain only one
})
export class AppModule { }
