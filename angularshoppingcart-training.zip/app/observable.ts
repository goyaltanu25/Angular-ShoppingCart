// a state with two values either resolve or reject
import {Observable} from "rxjs"

let ankur  =  function(tech){
    return new Promise(function(resolve,reject){

        setTimeout(()=>{
            // thinking wether he wants to take project or not
            if(tech=='angular'){
                resolve('yes i will take') // it will invoke first function inside then
            }
            else{
                reject(' get lost')
            }
        },5000)

    })
}  // ankur is promisiing to us that he will definitelt get back
ankur('angular').then((response)=>{
},(error)=>{
})


let puneet  = function(tech){
    return new Observable(function(observer){
        setTimeout(()=>{
            // thinking wether he wants to take project or not
            if(tech=='Java'){
                observer.next('yes i will take') // it will invoke first function inside then
            }
            else{
                observer.error(' get lost')
            }
        },5000)

        setTimeout(()=>{
            // his girlfriend called
            observer.next("No i will not take the [prject")
        },10000)
    })
}

puneet("Java").subscribe((rsponse)=>{},(error)=>{
  
})


var data =  readFile()

