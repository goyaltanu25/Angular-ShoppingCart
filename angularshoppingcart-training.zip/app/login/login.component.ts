import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login(){
    console.log("login started with", this.user)
    var url = "https://apibyashu.herokuapp.com/api/login"
    this.http.post(url,this.user).subscribe((response)=>{
      console.log("response from login api", response)
      if(response["token"]){
        this.cs.isloggedin = true
        localStorage.isloggedin=true
        localStorage.email=response["email"]
        localStorage.user = JSON.stringify(response)
        this.cs.user = response
        this.router.navigate(['/'])
      }
    },(error)=>{
      console.log("error from login api", error)
    })
  }

  user ={
    email:'',
    password:''
  }
  constructor(private cs :CommonService,  private http : HttpClient , private router : Router) { 
   
  }

  ngOnInit(): void {
  }

}
